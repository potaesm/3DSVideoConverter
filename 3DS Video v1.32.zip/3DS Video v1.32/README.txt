3DS Video v1.32
by SifJar

This is a program for converting videos to the 3DS.

Options:

Source Video - Choose the video you want to convert
Video Folder - Folder to place converted video in (e.g. 3DS video folder)
Format - Type of 3D video, or 2D video
Quality - Quality (31 is lowest, 1 is max)
Advanced... - Show advanced options (replace Quality with Bitrate & FPS)
Bitrate - Bitrate of converted video
Framerate - Framerate of converted video

Notes:

The included ffmpeg.exe is 32-bit. If you have a 64-bit CPU, you may want to replace it.

The official release thread: http://gbatemp.net/topic/315365-3ds-video-v01-beta/

Changelog:
-=v1.32=-
*Fixed: Simple Mode now rounds down the original framerate to the nearest integer and uses a maximum of 30 fps by BelowZero

-=v1.31=-
*Fixed problem with Progressbars when the program was canceled before
*Fixed MsgBox prompt in Simple Mode

-=v1.3=-
*Simple Mode now takes over the original framerate to a max of 30 fps by BelowZero
*Conversion of very short Testfiles works correctly now by BelowZero

-=v1.21=-
*Added choice of the duration of the test file option by BelowZero

-=v1.2=-
*Added media infos by BelowZero
*Added test file option by BelowZero
*Added several audio options by BelowZero
*Enabled upscaling of video framerate by BelowZero

-=v1.1=-
*Added keep aspect ratio option by amzg
*Improved progress bars by BelowZero 

-=v1.00=-
*GUI rewrite by amzg
*Mirrored input option fixed by amzg
*Progress bars added by BelowZero and amzg
*New error if destination folder has spaces
*GUI is disabled while converting

-=v0.30=-
*Added mirrored input option
*Added option for 480x240 resolution (default is still 400x240)

-=v0.23=-
*More bug fixes (thanks to amzg, xxNathanxx and Guy.brush at GBATemp)
*Remembers video folder
*Source tidied a bit

-=v0.22=-
*Fix splitting 3D video (thanks to Stylpe at GBATemp)

-=v0.21=-
*Fixing (some of) the bugs of v0.2

-=v0.2=-
*Added auto-splitting of files
*Added "Advanced..." options

-=v0.15=-
*Fixed bugs of v0.1

-=v0.1=-
*Initial release